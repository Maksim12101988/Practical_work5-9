from selenium.webdriver.common.by import By
from base_page import BasePage

class SkillBoxPage(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

    @property
    def search_button(self):
        return self.driver.find_element(By.XPATH, "/html/body/div[1]/div/div/main/div[1]/div[2]/div/div[1]/div[1]/div[1]/a[2]")

    @property
    def faculty_page_url(self):
        return "https://skillbox.ru/code/faculty/backend-development/"

    @property
    def first_section_elements(self):
        return self.driver.find_elements(By.XPATH, "/html/body/div[1]/div/div/main/div[1]/div[2]/div/div[2]/div/section[1]/div[2]/*")

    @property
    def second_section_elements(self):
        return self.driver.find_elements(By.XPATH, "/html/body/div[1]/div/div/main/div[1]/div[2]/div/div[2]/div/section[2]/div[2]/*")

    def click_search_button(self):
        self.wait_for_element_to_be_clickable(self.search_button)
        self.actions.click(self.search_button).perform()

    def navigate_to_faculty_page(self):
        self.wait_for_url_contains(self.faculty_page_url)
        self.driver.get(self.faculty_page_url)

    def get_first_section_texts(self):
        return [element.text for element in self.first_section_elements]

    def get_second_section_texts(self):
        return [element.text for element in self.second_section_elements]
