import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from Test_1.page_object import SkillBoxPage


@pytest.fixture(scope="function")
def driver():
    options = webdriver.ChromeOptions()
    options.add_argument('--start-maximized')

    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=options)

    yield driver
    driver.quit()


@pytest.mark.parametrize("url, expected_title", [
    ("https://skillbox.ru/code", "Skillbox"),
    ("https://www.google.com", "Google")
])
def test_page_title(driver, url, expected_title):
    driver.get(url)
    assert driver.title == expected_title, f"Expected title '{expected_title}', but got '{driver.title}'"


def test_skill_box_flow(driver):
    skill_box_page = SkillBoxPage(driver)
    driver.get("https://skillbox.ru/code")

    skill_box_page.click_search_button()
    skill_box_page.navigate_to_faculty_page()

    first_section_texts = skill_box_page.get_first_section_texts()
    second_section_texts = skill_box_page.get_second_section_texts()

    assert len(first_section_texts) > 0, "First section is empty"
    assert len(second_section_texts) > 0, "Second section is empty"


@pytest.mark.time_calc
def test_time_calc(driver):
    skill_box_page = SkillBoxPage(driver)
    driver.get("https://skillbox.ru/code")

    start_time = pytest.time()
    skill_box_page.click_search_button()
    skill_box_page.navigate_to_faculty_page()

    end_time = pytest.time()
    execution_time = end_time - start_time

    assert execution_time < 60, f"Test took too long! Time: {execution_time:.2f} seconds"
