import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from Test_1.page_object import SkillBoxPage


@pytest.mark.time_calc
def test_time_calc(driver):
    skill_box_page = SkillBoxPage(driver)
    driver.get("https://skillbox.ru/code")

    start_time = pytest.time()
    skill_box_page.click_search_button()
    skill_box_page.navigate_to_faculty_page()

    end_time = pytest.time()
    execution_time = end_time - start_time

    assert execution_time < 60, f"Test took too long! Time: {execution_time:.2f} seconds"
