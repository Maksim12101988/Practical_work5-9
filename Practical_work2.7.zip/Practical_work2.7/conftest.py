# conftest.py

import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager


@pytest.fixture(scope="function")
def driver():
    options = webdriver.ChromeOptions()
    options.add_argument('--start-maximized')

    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=options)

    yield driver
    driver.quit()


@pytest.hookimpl(tryfirst=True)
def pytest_configure(config):
    with open("Test_1/artifact.txt", "a") as f:
        f.write(f"Test run: {config.rootdir}\n")


@pytest.hookimpl(trylast=True)
def pytest_unconfigure(config):
    with open("Test_1/artifact.txt", "a") as f:
        f.write("Test completed\n")


@pytest.fixture(autouse=True)
def time_calc(request):
    def wrapper(*args, **kwargs):
        start_time = request.node.start_time
        result = request.node.func(*args, **kwargs)
        end_time = request.node.stop_time
        execution_time = end_time - start_time

        assert execution_time < 60, f"Test took too long! Time: {execution_time:.2f} seconds"

        return result

    return wrapper
